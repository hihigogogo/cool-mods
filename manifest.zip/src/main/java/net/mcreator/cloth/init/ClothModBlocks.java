
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cloth.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.cloth.block.ClothblockBlock;
import net.mcreator.cloth.ClothMod;

public class ClothModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ClothMod.MODID);
	public static final RegistryObject<Block> CLOTHBLOCK = REGISTRY.register("clothblock", () -> new ClothblockBlock());
}
