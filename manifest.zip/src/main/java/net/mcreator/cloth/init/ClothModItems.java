
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cloth.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.cloth.item.ClothitemItem;
import net.mcreator.cloth.item.ClothItem;
import net.mcreator.cloth.ClothMod;

public class ClothModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ClothMod.MODID);
	public static final RegistryObject<Item> CLOTHITEM = REGISTRY.register("clothitem", () -> new ClothitemItem());
	public static final RegistryObject<Item> CLOTH_HELMET = REGISTRY.register("cloth_helmet", () -> new ClothItem.Helmet());
	public static final RegistryObject<Item> CLOTH_CHESTPLATE = REGISTRY.register("cloth_chestplate", () -> new ClothItem.Chestplate());
	public static final RegistryObject<Item> CLOTH_LEGGINGS = REGISTRY.register("cloth_leggings", () -> new ClothItem.Leggings());
	public static final RegistryObject<Item> CLOTH_BOOTS = REGISTRY.register("cloth_boots", () -> new ClothItem.Boots());
	public static final RegistryObject<Item> CLOTHBLOCK = block(ClothModBlocks.CLOTHBLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
